README for the Midnight Repo.

This repo contains a simple Java program.

