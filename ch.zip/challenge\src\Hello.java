public class Hello {
    public static void main(String[] args) {
        // Flag removed from production build.
        System.out.println("Hello, Midnight Club");
    }
}